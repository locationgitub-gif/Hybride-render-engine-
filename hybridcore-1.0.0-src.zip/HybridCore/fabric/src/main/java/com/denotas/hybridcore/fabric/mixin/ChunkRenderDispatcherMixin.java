package com.denotas.hybridcore.fabric.mixin;

import com.denotas.hybridcore.HybridCore;
import net.minecraft.client.render.chunk.ChunkRenderDispatcher;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChunkRenderDispatcher.class)
public class ChunkRenderDispatcherMixin {

    @Inject(method = "scheduleRebuild", at = @At("HEAD"))
    private void hybridcore$onChunkRebuild(int x, int y, int z, boolean important, CallbackInfo ci) {
        HybridCore hc = HybridCore.getInstance();
        if (hc != null && hc.getTelemetry() != null) {
            hc.getTelemetry().recordChunkRender();
        }
    }
}
